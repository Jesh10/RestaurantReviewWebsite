"use strict";

//The express framework is built on top of the node. js framework and helps in fast-tracking development of server-based applications
const express = require("express");
const bodyParser = require("body-parser");

const cuisineController = require('./controllers/cuisineController');
const membersinfoController = require('./controllers/membersinfoController');
const restaurantController = require('./controllers/restaurantController');
const reviewController = require('./controllers/reviewController');


var cors = require('cors');

var app = express();
var host = "127.0.0.2";
var port = 8080;
app.use(cors());
//To serve static files such as images, CSS files, and JavaScript files, use the express.static built-in middleware function in Express.
app.use(express.static("./public"));
 
//To get inputs sent in the body of the request, we need to use the body-parse
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({limit: "50mb"}));

app.route('/cuisines').get(cuisineController.getAllCuisines);
app.route('/cuisines').post(cuisineController.addCuisine);
app.route('/cuisines/:CuisineId').put(cuisineController.updateCuisine);
app.route('/searchcuisine').post(cuisineController.searchCuisines);
app.route('/cuisines/:CuisineId').delete(cuisineController.deleteCuisine);

app.route('/membersinfo').get(membersinfoController.getAllMembers);
app.route('/user').post(membersinfoController.getMember);
app.route('/login').post(membersinfoController.loginMember);
app.route('/membersinfo').post(membersinfoController.addMember);
app.route('/searchmember').post(membersinfoController.searchMember);
app.route('/membersinfo').put(membersinfoController.updateMember);
app.route('/membersinfo/:Username').delete(membersinfoController.deleteMember);

//if the route is /search, call the movieController.getAllRestaurants
app.route('/restaurants').get(restaurantController.getAllRestaurants);
app.route('/restaurants').post(restaurantController.addRestaurant);
app.route('/restaurants/:RestaurantId').put(restaurantController.updateRestaurant);
app.route('/search').post(restaurantController.searchRestaurants);
app.route('/restaurants/:RestaurantId').delete(restaurantController.deleteRestaurant);
//if the route is /restaurant, call the movieController.searchRestaurant
app.route('/searchcuisine/:Cuisines').get(restaurantController.searchRestaurantCuisine);
app.route('/email').post(restaurantController.sendEmail);

app.route('/review').get(reviewController.getAllReviews);
app.route('/review').post(reviewController.addReview);
app.route('/review/:ReviewId').put(reviewController.updateReview);
app.route('/review/:ReviewId').delete(reviewController.deleteReview);
app.route('/searchmemberreview').post(reviewController.searchMemberReview);




//This app starts a server and listens on port 8080 for connection
var server = app.listen(port, host, function() {
    var host = server.address().address;
    var port = server.address().port;

    console.log("Example Apps listen at http://%s:%s", host, port);
});
