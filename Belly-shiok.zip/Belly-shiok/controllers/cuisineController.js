"use strict";
const CuisinesDB = require('../models/CuisinesDb');
const Cuisine = require('../models/Cuisine');
var cuisinesDB = new CuisinesDB();

function getAllCuisines(request, respond){

    cuisinesDB.getAllCuisines(function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });

}

function addCuisine(request, respond){
    var Name = request.body.Name;
    var Thumbnail = request.body.Thumbnail
    cuisinesDB.addCuisine(Name, Thumbnail, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });

}

function updateCuisine(request, respond){
    var cuisine = new Cuisine(parseInt(request.params.CuisineId),request.body.Name, request.body.Thumbnail);
    cuisinesDB.updateCuisine(cuisine, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}

function searchCuisines(request, respond){
    var searchTerm = request.body.search;
    cuisinesDB.searchCuisines(searchTerm, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });

}

function deleteCuisine(request, respond){
    var CuisineId = request.params.CuisineId;
    cuisinesDB.deleteCuisine(CuisineId, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}

module.exports = { getAllCuisines, addCuisine, updateCuisine, searchCuisines, deleteCuisine};