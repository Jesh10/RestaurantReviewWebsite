"use strict";
const RestaurantsDB = require('../models/RestaurantsDb');
const Restaurant = require('../models/Restaurant');
const sgMail = require('@sendgrid/mail')
var restaurantsDB = new RestaurantsDB();

function getAllRestaurants(request, respond) {

    restaurantsDB.getAllRestaurants(function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });

}

function addRestaurant(request, respond) {
    var Website = request.body.Website;
    var Name = request.body.Name;
    var Cuisines = request.body.Cuisines;
    var Description = request.body.Description;
    var Longitude = request.body.Longitude;
    var Latitude = request.body.Latitude;
    var Location = request.body.Location;
    var OpeningHours = request.body.OpeningHours;
    var Thumbnail = request.body.Thumbnail
    var Poster = request.body.Poster;
    restaurantsDB.addRestaurant(Website, Name, Cuisines, Description, Longitude, Latitude, Location, OpeningHours, Thumbnail, Poster, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    })
}

function updateRestaurant(request, respond) {
    var restaurant = new Restaurant(parseInt(request.params.RestaurantId), request.body.Website, request.body.Name, request.body.Cuisines, request.body.Description, request.body.Price, request.body.Longitude, request.body.Latitude, request.body.Location, request.body.OpeningHours, request.body.Thumbnail, request.body.Poster);
    restaurantsDB.updateRestaurant(restaurant, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });
}

function searchRestaurants(request, respond) {
    var searchTerm = request.body.search;
    restaurantsDB.searchRestaurants(searchTerm, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });

}

function searchRestaurantCuisine(request, respond) {
    var Cuisines = request.params.Cuisines;
    restaurantsDB.searchRestaurantCuisine(Cuisines, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });

}

function deleteRestaurant(request, respond) {
    var RestaurantId = request.params.RestaurantId;
    restaurantsDB.deleteRestaurant(RestaurantId, function (error, result) {
        if (error) {
            respond.json(error);
        }
        else {
            respond.json(result);
        }
    });
}

function sendEmail(request, respond) {
    var email = request.body.email;
    var content = request.body.content;
    sgMail.setApiKey("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")
    const msg = {
        to: email, // Change to your recipient
        from: '	2000239J@student.tp.edu.sg', // Change to your verified sender
        subject: 'CDEV is Fun',
        text: content,
        html: '<strong>'+ content +'</strong>',
    }
    sgMail
        .send(msg)
        .then(() => {
            console.log('Email sent');
            respond.json({result:"success"});
        })
        .catch((error) => {
            console.error(error)
            respond.json({result:"fail"});
        })
}

module.exports = { getAllRestaurants, addRestaurant, updateRestaurant, searchRestaurants, searchRestaurantCuisine, deleteRestaurant, sendEmail };