"use strict";
const MembersInfoDB = require('../models/MembersInfoDb');
const Member = require('../models/MembersInfo');
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken')
var membersinfoDB = new MembersInfoDB();
var secret = "somesecretkey"

function getAllMembers(request, respond){
    membersinfoDB.getAllMembers(function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });

}

function getMember(request, respond){
    var token = request.body.token;
    try {
        var decoded = jwt.verify(token,secret);
        membersinfoDB.getMember(decoded, function(error, result){
            if(error){
                respond.json(error);
            }
            else{
                respond.json(result);
            }
        });

    } catch (error) {
        respond.json({result:"invalid token"});
    }
}


function loginMember(request, respond){
    var Username = request.body.Username;
    var Password = request.body.Password;
    membersinfoDB.loginMember(Username, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            if(result.length > 0){
            const hash = result[0].Password;
            var flag = bcrypt.compareSync(Password,hash);
            if (flag){
                var token = jwt.sign(Username,secret);
                respond.json({result:token, MemberId:result[0].MemberId});
            }else {
                respond.json({result:"invalid"});
            }
        }else{
            respond.json({result:"User does not exist"});
        }
        }
    })
}

function addMember(request, respond){
    var Username = request.body.Username;
    var Email = request.body.Email;
    var Password = request.body.Password;
    Password = bcrypt.hashSync(Password,10);
    membersinfoDB.addMember(Username, Email, Password, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    })
}


function searchMember(request, respond){
    var searchTerm = request.body.search;
    membersinfoDB.searchMember(searchTerm, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });

}

function updateMember(request, respond){
    var FirstName = request.body.FirstName;
    var LastName = request.body.LastName;
    var Gender = request.body.Gender;
    var DateofBirth = request.body.DateofBirth;
    var Picture = request.body.Picture;
    var token = request.body.token;
    try {
        var decoded = jwt.verify(token,secret);
        membersinfoDB.updateMember(decoded, FirstName, LastName, Gender, DateofBirth, Picture, function(error, result){
            if(error){
                respond.json(error);
            }
            else{
                respond.json(result);
            }
        });
    } catch (error) {
        respond.json({result:"invalid token"});
    }
}

function deleteMember(request, respond){
    var Username = request.params.Username;
    membersinfoDB.deleteMember(Username, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}


module.exports = { getAllMembers, getMember, loginMember, addMember, searchMember, updateMember, deleteMember};
 
