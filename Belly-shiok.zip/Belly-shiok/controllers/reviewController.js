"use strict";
const ReviewsDB = require('../models/ReviewsDb');
const Review = require('../models/Review');

var reviewsDB = new ReviewsDB();

function getAllReviews(request, respond){
    reviewsDB.getAllReviews(function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });

}

function addReview(request, respond){
    var MemberId = request.body.MemberId;
    var RestaurantId = request.body.RestaurantId;
    var RestaurantName = request.body.RestaurantName;
    var MemberName = request.body.MemberName;
    var CreatedAt = new Date();
    var UpdatedAt = new Date();
    var Rating = request.body.Rating;
    var Description = request.body.Description;
    
    reviewsDB.addReview(MemberId, RestaurantId, RestaurantName, MemberName, CreatedAt.toString(), UpdatedAt.toString(), Rating, Description, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    })
}

function updateReview(request, respond){
    var UpdatedAt = new Date();
    var review = new Review(parseInt(request.params.ReviewId), request.body.MemberId, request.body.RestaurantId, request.body.RestaurantName, request.body.MemberName, request.body.CreatedAt, UpdatedAt.toString(), request.body.Rating, request.body.Description);
    reviewsDB.updateReview(review, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}


function deleteReview(request, respond){
    var reviewID = request.params.ReviewId;
    reviewsDB.deleteReview(reviewID, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}

function searchMemberReview(request, respond){
    var searchTerm = request.body.search;
    reviewsDB.searchMemberReview(searchTerm, function(error, result){
        if(error){
            respond.json(error);
        }
        else{
            respond.json(result);
        }
    });
}
module.exports = {getAllReviews, addReview, updateReview, deleteReview, searchMemberReview};
 
