"use strict";

class Review {
    constructor(ReviewId, MemberId, RestaurantId, RestaurantName, MemberName, CreatedAt, UpdatedAt, Rating, Description) {
        this.ReviewId = ReviewId;
        this.MemberId = MemberId;
        this.RestaurantId = RestaurantId;
        this.RestaurantName = RestaurantName;
        this.MemberName = MemberName
        this.CreatedAt = CreatedAt;
        this.UpdatedAt = UpdatedAt;
        this.Rating = Rating;
        this.Description = Description;
    }

    getReviewId() {
        return this.ReviewId;
    }

    getMemberId() {
        return this.MemberId;
    }

    getRestaurantId() {
        return this.RestaurantId;
    }

    getRestaurantName() {
        return this.RestaurantName;
    }

    getMemberName(){
        return this.MemberName
    }

    getCreatedAt() {
        return this.CreatedAt;
    }

    getUpdatedAt() {
        return this.UpdatedAt;
    }

    getRating() {
        return this.Rating;
    }

    getDescription() {
        return this.Description;
    }

    setMemberId(MemberId) {
        this.MemberId = MemberId;
    }

    setRestaurantId(RestaurantId) {
        this.RestaurantId = RestaurantId;
    }

    setRestaurantName(RestaurantName) {
        this.RestaurantName = RestaurantName;
    }

    setMemberName(MemberName){
        this.MemberName = MemberName
    }

    setCreatedAt(CreatedAt) {
        this.CreatedAt = CreatedAt;
    }

    setUpdatedAt(UpdatedAt) {
        this.UpdatedAt = UpdatedAt;
    }

    setRating(Rating) {
        this.Rating = Rating;
    }

    setDescription(Description) {
        this.Description = Description;
    }
}

module.exports = Review;