"use strict";

class Cuisine {
    constructor(CuisineId, Name, Thumbnail) {
        this.CuisineId = CuisineId;
        this.Name = Name;
        this.Thumbnail = Thumbnail;
    }

    getCuisineId() {
        return this.CuisineId;
    }

    getName() {
        return this.Name;
    }

    getThumbnail() {
        return this.Thumbnail;
    }

    setName(Name) {
        this.Name = Name;
    }

    setThumbnail(Thumbnail) {
        this.Thumbnail = Thumbnail;
    }
}

module.exports = Cuisine;