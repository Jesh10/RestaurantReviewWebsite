"use strict";

//refernce the connection file and make a connection to mysql
var db = require('../db-connection');

class RestaurantsDB{

    //create a function to get All restaurants
    getAllRestaurants(callback){
        var sql = "SELECT * FROM Restaurant";
        db.query(sql, callback);
    }

    addRestaurant(Website, Name, Cuisines, Description, Longitude, Latitude, Location, OpeningHours, Thumbnail, Poster, callback){
        var sql = "INSERT INTO Restaurant ( Website, Name, Cuisines, Description, Longitude, Latitude, Location, OpeningHours, Thumbnail, Poster) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        db.query(sql, [Website, Name, Cuisines, Description, Longitude, Latitude, Location, OpeningHours, Thumbnail, Poster], callback);
    }

    updateRestaurant(restaurant, callback){
        var sql = "UPDATE Restaurant SET Cuisines = ?, Description = ?, Price = ?, Location = ?, OpeningHours = ? WHERE RestaurantId = ?";
        return db.query(sql, [restaurant.getCuisines(), restaurant.getDescription(), restaurant.getPrice(), restaurant.getLocation(), restaurant.getOpeningHours(), restaurant.getRestaurantId()], callback);
    }

    //create a function to search for restaurants
    searchRestaurants(keyword, callback){
        var key = "%" + keyword + "%";
        var sql = "SELECT * FROM restaurant WHERE Name like ?";
        return db.query(sql,[key], callback);
    }

    searchRestaurantCuisine(Cuisines, callback){
        var sql = "SELECT * FROM restaurant WHERE Cuisines = ? ";
        return db.query(sql, [Cuisines], callback);
    }

    deleteRestaurant(restaurantId, callback){
        var sql = "DELETE FROM Restaurant WHERE RestaurantId = ?";
        return db.query(sql, [restaurantId], callback);
    }

}

module.exports = RestaurantsDB;