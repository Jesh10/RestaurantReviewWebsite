"use strict";

//refernce the connection file and make a connection to mysql
var db = require('../db-connection');

class CuisinesDB{

    //create a function to get All Cuisines
    getAllCuisines(callback){
        var sql = "SELECT * FROM Cuisines";
        db.query(sql, callback);
    }

    addCuisine(Name, Thumbnail, callback){
        var sql = "INSERT INTO Cuisines (Name, Thumbnail) VALUES (?, ?)";
        db.query(sql, [Name, Thumbnail], callback);
    }

    updateCuisine(cuisine, callback){
        var sql = "UPDATE Cuisines SET Name = ?, Thumbnail = ? WHERE CuisineId = ?";
        return db.query(sql, [cuisine.getName(), cuisine.getThumbnail(), cuisine.getCuisineId()], callback);
    }

    //create a function to search for Cuisines
    searchCuisines(keyword, callback){
        var key = "%" + keyword + "%";
        var sql = "SELECT * FROM Cuisines WHERE Name like ?  ";
        db.query(sql,[key], callback);
    }

    deleteCuisine(CuisineId, callback){
        var sql = "DELETE FROM Cuisines WHERE CuisineId = ?";
        return db.query(sql, [CuisineId], callback);
    }
}

module.exports = CuisinesDB;