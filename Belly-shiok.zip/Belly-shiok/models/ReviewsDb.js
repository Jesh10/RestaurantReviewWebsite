"use strict";

var db = require('../db-connection');

class ReviewsDB{
    getAllReviews(callback){
        var sql = "SELECT * FROM Review";
        db.query(sql, callback);
    }

    getReviewCount(ReviewId,callback){
        var sql = "SELECT Count(ReviewId) FROM Review WHERE RestaurantName = ?";
        return db.query(sql,[ReviewId], callback);
    }
    
    addReview(MemberId, RestaurantId, RestaurantName, MemberName, CreatedAt, UpdatedAt, Rating, Description, callback){
        var sql = "INSERT INTO Review (MemberId, RestaurantId, RestaurantName, MemberName, CreatedAt, UpdatedAt, Rating, Description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        db.query(sql, [MemberId, RestaurantId, RestaurantName, MemberName, CreatedAt, UpdatedAt, Rating, Description], callback);
    }    

    updateReview(review, callback){
        var sql = "UPDATE Review SET MemberName = ?, UpdatedAt = ?, Rating = ?, Description = ? WHERE ReviewId = ?";
        return db.query(sql, [review.getMemberName(), review.getUpdatedAt(), review.getRating(), review.getDescription(), review.getReviewId()], callback);
    }

    deleteReview(reviewID, callback){
        var sql = "DELETE FROM Review WHERE ReviewId = ?";
        return db.query(sql, [reviewID], callback);
    }

    searchMemberReview(keyword, callback){
        var key = "%" + keyword + "%";
        var sql = "SELECT restaurant.Name, review.CreatedAt, review.UpdatedAt, review.Rating, review.Description FROM review INNER JOIN restaurant ON review.RestaurantId = restaurant.RestaurantId WHERE review.MemberName like ? ";
        return db.query(sql, [key], callback);
    }

}

module.exports = ReviewsDB;