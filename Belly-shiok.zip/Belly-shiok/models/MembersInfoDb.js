"use strict";

var db = require('../db-connection');

class MembersInfoDB{

    getAllMembers(callback){
        var sql = "SELECT Username, FirstName, LastName FROM MembersInfo";
        db.query(sql, callback);
    }

    getMember(Username,callback){
        var sql = "SELECT distinct Username, FirstName, LastName, Gender, DateofBirth, Picture FROM MembersInfo WHERE Username = ?";
        db.query(sql,[Username], callback);
    }

    loginMember(Username, callback){
        var sql = "SELECT * FROM MembersInfo WHERE Username = ?";
        db.query(sql, [Username], callback);
    }

    addMember(Username, Email, Password, callback){
        var sql = "INSERT INTO MembersInfo (Username, Email, Password) VALUES (?, ?, ?)";
        db.query(sql, [Username, Email, Password ], callback);
    }

    searchMember(keyword, callback){
        var key = "%" + keyword + "%";
        var sql = "SELECT * FROM MembersInfo WHERE Username like ? ";
        return db.query(sql, [key], callback);
    }

    updateMember(Username, FirstName, LastName, Gender, DateofBirth, Picture, callback){
        var sql = "UPDATE MembersInfo SET FirstName = ?, LastName = ?, Gender = ?, DateofBirth = ?, Picture = ? WHERE Username = ?";
        return db.query(sql, [FirstName, LastName, Gender, DateofBirth, Picture, Username], callback);
    }

    deleteMember(Username, callback){
        var sql = "DELETE FROM MembersInfo WHERE Username = ?";
        return db.query(sql, [Username], callback);
    }


}

module.exports = MembersInfoDB;