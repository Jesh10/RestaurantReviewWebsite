"use strict";

class MembersInfo {
    constructor(MemberId, FirstName, LastName, Username, Email, Password, Gender, DateofBirth) {
        
        this.MemberId = MemberId;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Username = Username;
        this.Email = Email;
        this.Password = Password;
        this.Gender = Gender;
        this.DateofBirth = DateofBirth;
    }

    getMemberId() {
        return this.MemberId;
    }

    getFirstName() {
        return this.FirstName;
    }

    getLastName() {
        return this.LastName;
    }

    getUsername(){
        return this.Username;
    }

    getEmail() {
        return this.Email;
    }

    getPassword() {
        return this.Password;
    }

    getGender() {
        return this.Gender;
    }

    getDateofBirth() {
        return this.DateofBirth;
    }

    setFirstName(FirstName) {
        this.FirstName = FirstName;
    }

    setLastName(LastName) {
        this.LastName = LastName;
    }

    setUsername(Username){
        this.Username = Username;
    }

    setEmail(Email) {
        this.Email = Email;
    }

    setPassword(Password) {
        this.Password = Password;
    }

    setGender(Gender) {
        this.Gender = Gender;
    }

    setDateofBirth(DateofBirth) {
        this.DateofBirth = DateofBirth;
    }
}

module.exports = MembersInfo;