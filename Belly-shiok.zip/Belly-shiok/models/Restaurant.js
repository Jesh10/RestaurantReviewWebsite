"use strict";

class Restaurant {
    constructor(RestaurantId, Website, Name, Cuisines, Description, Longitude, Latitude, Location, OpeningHours, Thumbnail, Poster) {
        this.RestaurantId = RestaurantId;
        this.Website = Website;
        this.Name = Name;
        this.Cuisines = Cuisines
        this.Description = Description;
        this.Longitude = Longitude;
        this.Latitude = Latitude;
        this.Location = Location;
        this.OpeningHours = OpeningHours;
        this.Thumbnail = Thumbnail;
        this.Poster = Poster;
    }

    getRestaurantId() {
        return this.RestaurantId;
    }

    getWebsite() {
        return this.Website;
    }

    getName() {
        return this.Name;
    }

    getCuisines(){
        return this.Cuisines
    }

    getDescription() {
        return this.Description;
    }

    getLongitude() {
        return this.Longitude;
    }

    getLatitude() {
        return this.Latitude;
    }

    getLocation() {
        return this.Location;
    }

    getOpeningHours() {
        return this.OpeningHours;
    }

    getThumbnail() {
        return this.Thumbnail;
    }

    getPoster() {
        return this.Poster;
    }

    setWebsite(Website) {
        this.Website = Website;
    }

    setName(Name) {
        this.Name = Name;
    }

    setCuisines(Cuisines){
        this.Cuisines = Cuisines
    }

    setDescription(Description) {
        this.Description = Description;
    }

    setLongitude(Longitude) {
        this.Longitude= Longitude;
    }

    setLatitude(Latitude) {
        this.Latitude= Latitude;
    }

    setLocation(Location) {
        this.Location = Location;
    }

    setOpeningHours(OpeningHours) {
        this.OpeningHours = OpeningHours;
    }

    setThumbnail(Thumbnail) {
        this.Thumbnail = Thumbnail;
    }

    setPoster(Poster) {
        this.Poster = Poster;
    }
}

module.exports = Restaurant;