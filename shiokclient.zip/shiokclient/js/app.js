var restaurant_url = "http://127.0.0.2:8080/restaurants";
var restaurant_array = []; // This creates an empty restaurant array
var restaurantCount = 0;

var restaurantcuisine_url = "http://127.0.0.2:8080/searchcuisine";

var search_url = "http://127.0.0.2:8080/search";
/*  There are two categories: "Now Showing" and "Coming Soon". This variable states which 
    category of restaurants should be listed when the home page is first loaded. */
var currentIndex = 0;

var cuisine_url = "http://127.0.0.2:8080/cuisines";
var cuisine_array = [];
var cuisineCount = 0;


var review_url = "http://127.0.0.2:8080/review";
var review_array = []; // This creates an empty review array
var Rating = 0;

var popcornBWImage = "images/star_bw.png"
var popcornImage = "images/star_gold.png"
