//This function is to call the restaurants api and get all the restaurants
//that is showing in Shaw Theatres for Showing Now and Coming Soon
function getRestaurantData() {
    var request = new XMLHttpRequest();
    request.open('GET', restaurant_url , true);

    //This function will be called when data returns from the web api
    request.onload = function() {
        //get all the restaurants records into our restaurant array
        restaurant_array = JSON.parse(request.responseText);
        console.log(restaurant_array)
        fetchReview();
        //call the function so as to display all restaurants tiles for "Now Showing"
        displayRestaurants()
    };
    
    //This command starts the calling of the restaurants web api
    request.send();
}

//This function is to display the restaurants tiles
//that filters based on "Now Showing" or "Coming Soon"
function displayRestaurants() {
    var table = document.getElementById("restaurantsTable");
    var message = "";
    
    table.innerHTML = "";
    totalRestaurants = restaurant_array.length;
    for (var count = 0; count < totalRestaurants; count++) {
        var thumbnail = "http://127.0.0.2:8080/" +restaurant_array[count].Thumbnail;
        var Name = restaurant_array[count].Name;

        var cell = '<div class="card" style="width: 16rem; margin-left: 100px; margin-bottom: 20px; border:solid black;"> \
                    <img style="height:150px;width:100%;" class="img-fluid img-Thumbnail " src="' + thumbnail + '" /> \
                        <div class="card-body"> \
                            <span style="font-size:22px; font-weight: bold; font-colour: #A9A9A9";>' + Name + '</span><br>                                                                                                                                                                      \
                            <button href="" data-toggle="modal" data-target="#restaurantModal" item="' + count + '" type="button" class="btn btn-primary btn-s" onClick="showRestaurantDetails(this); showRestaurantReview(this)" style="margin-top: 10px">See More</button>                 \
                            <button href="" data-toggle="modal" data-target="#reviewModal" item="' + count + '" type="button" class="btn btn-primary btn-s" onClick="showRestaurantReview(this)" style="margin-top: 10px">Reviews</button>              \
                        </div> \
                    </div>';

        table.insertAdjacentHTML('beforeend', cell);
        restaurantCount++;
    }

    message = "What are you craving for?";
    document.getElementById("summary").textContent = message;
    document.getElementById("parent").textContent = "";
}

//This function is to display the individual restaurants details
//whenever the user clicks on "See More"
function showRestaurantDetails(element) {
    var item = element.getAttribute("item");
    
    currentIndex = item;
    console.log(restaurant_array[item].Website)
    document.getElementById("Name").textContent = restaurant_array[item].Name;
    document.getElementById("Cuisines").textContent = restaurant_array[item].Cuisines;
    document.getElementById("Description").textContent = restaurant_array[item].Description;
    document.getElementById("Address").textContent = restaurant_array[item].Address;
    document.getElementById("OpeningHours").textContent = restaurant_array[item].OpeningHours;
    document.getElementById("Poster").src = "http://127.0.0.2:8080/" + restaurant_array[item].Poster;
    showMap() ;
}

function showMap() {

    var locations = [restaurant_array[currentIndex].Location, restaurant_array[currentIndex].Longitude, restaurant_array[currentIndex].Latitude];
    map = new google.maps.Map(document.getElementById("map"),{center:{lat:1.8, lng:110.9},zoom:4});
    var infowindow = new google.maps.InfoWindow();
    var marker, i;
    var markers = [];

    marker = new google.maps.Marker({
        position : new google.maps.LatLng(locations[1],locations[2]),
        map:map,
        icon : {
            url: "http://maps.google.com/mapfiles/ms/icons/restaurant.png"
        }

    });

    markers.push(marker);
    google.maps.event.addListener(marker,'click',(function(marker,i){
        return function (){
            infowindow.setContent(locations[0]);
            infowindow.open(map,marker);
        }
    })(marker, i));

    navigator.geolocation.getCurrentPosition(
        (position)=>{
            const pos = {
                lat:position.coords.latitude,
                lng:position.coords.longitude,
            }
            map.setCenter(pos);
            map.setZoom(15);
            marker = new google.maps.Marker({
                position: new google.maps.LatLng(pos.lat, pos.lng),
                map: map,
                icon: {
                    url:"http://maps.google.com/mapfiles/ms/icons/red-dot.png"
                }
            })

            markers.push(marker);
            google.maps.event.addListener(marker,'click',(function(marker,i){
                return function (){
                    infowindow.setContent("Your Current Location");
                    infowindow.open(map,marker);
                }
            })(marker, i));
        }
    )
}


//This function opens a new window/tab and loads the
//particular restaurant in the cinema website
function websitelink() {
    window.open(restaurant_array[currentIndex].Website, "_blank");
}