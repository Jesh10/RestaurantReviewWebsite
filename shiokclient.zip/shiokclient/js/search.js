function search() {
  var search = new XMLHttpRequest();

  search.open("POST", search_url, true);
  //tells server side that data will come in JSON format
  search.setRequestHeader("Content-Type","application/json");
  search.onload = function () {
      //append new restaurant results into restaurant_array
      restaurant_array = JSON.parse(search.responseText);
      //call the function so as to display all movies tiles for "Now Showing"
      displayRestaurants();
  };

var searchTerm = document.getElementById("searchName").value;
// inserts data in curly braces so server can read
var payload = {search:searchTerm}
//sends request in JSON format to server
search.send(JSON.stringify(payload));
}
function searchRestaurants() {
  document.getElementById("searchMenu").classList.add("active");
}