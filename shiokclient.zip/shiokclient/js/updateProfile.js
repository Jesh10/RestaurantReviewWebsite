function encode() {

    var selectedfile = document.getElementById("myinput").files;
    if (selectedfile.length > 0) {
        var imageFile = selectedfile[0];
        var fileReader = new FileReader();
        fileReader.onload = function (fileLoadedEvent) {
            Picture = fileLoadedEvent.target.result;
            document.getElementById('target').src = Picture;
        }
        fileReader.readAsDataURL(imageFile);
    }
}

function update() {

    var updateUser = new XMLHttpRequest();

    updateUser.open("PUT", "http://127.0.0.2:8080/membersinfo", true);
    updateUser.setRequestHeader("Content-Type", "application/json");
    updateUser.onload = function () {

    }
    FirstName = document.getElementById("FirstName").value;
    LastName = document.getElementById("LastName").value;
    Gender = document.getElementById("Gender").value;
    DateofBirth = document.getElementById("DateofBirth").value;
    var payload = { token: token, FirstName: FirstName, LastName: LastName, Gender: Gender, DateofBirth: DateofBirth, Picture: Picture }
    updateUser.send(JSON.stringify(payload));

}

function deleteprofile(){
    var response = confirm("Are you sure you want to delete this profile?");

    if (response == true) {
        var delete_profile_url = "http://127.0.0.2:8080/membersinfo" + "/" + Username;
        var eraseprofile = new XMLHttpRequest();
        eraseprofile.open("DELETE", delete_profile_url, true);
        eraseprofile.send();
        sessionStorage.removeItem("token");
    }else{
        pass
    }

}