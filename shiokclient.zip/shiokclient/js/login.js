function loginMe(){

    var loginUser = new XMLHttpRequest();

    loginUser.open("POST","http://127.0.0.2:8080/login",true);
    loginUser.setRequestHeader("Content-Type", "application/json");
    loginUser.onload = function(){

        var token = JSON.parse(loginUser.responseText);
        console.log(token.result);
        if (token.result != "User does not exist") {
            var loginUsername = "Welcome Back " + document.getElementById("Usernamelogin").value + "!";
            document.getElementById("loginUsername").textContent = loginUsername;
            $('#loginsuccessModal').modal('show');
            document.getElementById("registerMenu").style.display="none";
            document.getElementById("loginMenu").style.display="none";
            document.getElementById("logoutMenu").style.display="block";
            document.getElementById("editMenu").style.display="block";
            
            sessionStorage.setItem("token",token.result)
        } else {    
            $('#failModal').modal('show');
        }

    }

    var Username = document.getElementById("Usernamelogin").value;
    var Password = document.getElementById("Passwordlogin").value;
    var payload = {Username:Username, Password:Password, FirstName:FirstName, LastName:LastName, Email:Email}
    loginUser.send(JSON.stringify(payload));
}