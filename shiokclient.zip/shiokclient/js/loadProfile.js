$(document).ready(function(){

    var getProfile = new XMLHttpRequest();

    getProfile.open("POST","http://127.0.0.2:8080/user", true);
    getProfile.setRequestHeader("Content-Type","application/json");
    getProfile.onload = function (){
        var profile = JSON.parse(getProfile.responseText);
        console.log(getProfile.responseText);
        Username = profile[0].Username;
        FirstName = profile[0].FirstName;
        LastName = profile[0].LastName;
        Gender = profile[0].Gender;
        DateofBirth= profile[0].DateofBirth;
        Picture = profile[0].Picture;
        document.getElementById('Username').value = Username;
        document.getElementById('FirstName').value = FirstName;
        document.getElementById('LastName').value = LastName;
        document.getElementById('Gender').value = Gender;
        document.getElementById('DateofBirth').value = DateofBirth;
        document.getElementById('target').src = Picture;
        
    }

    var payload = {token : token};
    getProfile.send(JSON.stringify(payload));

    

})

