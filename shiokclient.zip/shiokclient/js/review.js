function fetchReview() {
    var request = new XMLHttpRequest();

    request.open('GET', review_url, true);

    //This command starts the calling of the Review web api
    request.onload = function () {
        //get all the Review records into our Review array
        review_array = JSON.parse(request.responseText);
        console.log(review_array)
    };

    request.send();
}

//This function is to display all the Review of that Restaurant
//whenever the user click on the "review" button
function showRestaurantReview(element) {
    document.getElementById("emptyreview").innerHTML = "No review yet. Create one now";
    var item = element.getAttribute("item");
    currentIndex = item;
    //var reviewModal = new Modal(document.getElementById("reviewModal"));

    document.getElementById("review").textContent = "Review for " + restaurant_array[item].Name;
    document.getElementById("reviewBody").textContent = "";

    for (var i = 0; i < review_array.length; i++) {
        if (review_array[i].RestaurantName.trim() === restaurant_array[item].Name.trim()) {
            document.getElementById("emptyreview").innerHTML = "";
            selectedRestaurantId = restaurant_array[item].RestaurantId;
            star = "";

            var html = '<div class="card mb-3" style="width:100%">   \
                            <div class="card-body">  \
                                <ul class="navbar-nav mr-auto"> \
                                    <li class = "nav-item" style="font-size: 40px">   \
                                        <a class="card-title">'+ review_array[i].MemberName +'</a>\
                                    </li>\
                                </ul>\
                                <ul class="navbar-nav"> \
                                    <li class = "nav-item">   \
                                        <p class="card-text"><small class="text-muted">Created At: '+ review_array[i].CreatedAt +'</small></p>  \
                                    </li>\
                                </ul>\
                                <ul class="navbar-nav"> \
                                    <li class = "nav-item">   \
                                        <p class="card-text"><small class="text-muted">Updated At: '+ review_array[i].UpdatedAt +'</small></p>  \
                                    </li>\
                                </ul>\
                                <ul class="nav nav-tabs card-header-tabs"> \
                                    <li class="card-body"> \
                                        <p class="card-text" style="font-size: 20px">' + review_array[i].Description + '</p>               \
                                        <p class="card-text" id="Rating' + i + '"></p>               \
                                    </li>  \
                                </ul>\
                            </div>  \
                        </div>';

            document.getElementById("reviewBody").insertAdjacentHTML('beforeend', html);

            
            var star = "";
            for (var j = 0; j < review_array[i].Rating; j++){
                star += "<img src='images/star_gold.png' style='width:50px' />";
            }
            
            if (Username == review_array[i].MemberName){
                star += "<img src='images/delete.png' class='edit' data-dismiss='modal' item='" + i + "' onClick='deleteReview(this)' />";
                star += "<img src='images/edit.png' class='edit' data-toggle='modal' data-target='#editReviewModal' data-dismiss='modal' item='" + i + "' onClick='editReview(this)' />";
                document.getElementById("Rating" + i).insertAdjacentHTML('beforebegin', star + "<br />");
            }else{
                document.getElementById("Rating" + i).insertAdjacentHTML('beforebegin', star + "<br />");
            }            
        }
    }
}

function newreview() {
    // Initialise each HTML input elements in the modal window with default value.
    var token = sessionStorage.getItem("token");
    if (token !== null) {
        $('#newReviewModal').modal('show')
        Rating = 0;
        document.getElementById("userReview").value = "";
        document.getElementById("MemberName").value = "";

    } else {
        window.alert("Please Log in to Add Review");
    }

}

// Submit or send the new review to the server to be added.
function addReview() {
    var review = new Object();
    review.RestaurantId = restaurant_array[currentIndex].RestaurantId; // Restaurant ID is required by server to create new review
    review.RestaurantName = restaurant_array[currentIndex].Name;
    review.MemberId = review_array[currentIndex].MemberId; // Restaurant Name is required by server to create new review
    review.MemberName = document.getElementById("MemberName").value; // Value from HTML input text
    review.Description = document.getElementById("userReview").value; // Value from HTML input text
    review.CreatedAt = null; // Change the datePosted to null instead of taking the timestamp on the client side;
    review.Rating = Rating;
    console.log(review)
    var postReview = new XMLHttpRequest(); // new HttpRequest instance to send review

    postReview.open("POST", review_url, true); //Use the HTTP POST method to send data to server

    postReview.setRequestHeader("Content-Type", "application/json");
    postReview.onload = function() {
        fetchReview(); // fetch all Review again so that the web page can have updated Review.
    };

    postReview.send(JSON.stringify(review)); // Convert the data in review object to JSON format
    // before sending to the server.
}

//This function allows the user to mouse hover the black and white popcorn
//so that it will turn to a colored version when hovered
function rateIt(element) {
    var num = element.getAttribute("value");
    var classname = element.getAttribute("class");
    var popcorns = document.getElementsByClassName(classname);
    var classTarget = "." + classname;

    // This is another way of writing 'for' loop, which initialises the
    // popcorn images to use black and white.
    for (let popcorn of popcorns){
        popcorn.setAttribute("src", popcornBWImage);
    }
    changePopcornImage(num, classTarget);
}

// This function sets the rating and coloured images based on the value of the image tag when
// the mouse cursor hovers over the popcorn image.
function changePopcornImage(num, classTarget) {
    switch (eval(num)) {
        case 1:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", popcornImage);
            Rating = 1;
            break;
        case 2:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", popcornImage);
            Rating = 2;
            break;
        case 3:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='3']").setAttribute("src", popcornImage);
            Rating = 3;
            break;
        case 4:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='3']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='4']").setAttribute("src", popcornImage);
            Rating = 4;
            break;
        case 5:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='3']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='4']").setAttribute("src", popcornImage);
            document.querySelector(classTarget + "[value='5']").setAttribute("src", popcornImage);
            Rating = 5;
            break;
    }
}

//This function will hide the existing modal and present a modal with the selected review
//so that the user can attempt to change the username, rating or Restaurant review
function editReview(element) {
    var token = sessionStorage.getItem("token");
    if (token !== null) {
        var item = element.getAttribute("item");
        currentIndex = item;
        document.getElementById("editMemberName").value = review_array[item].MemberName;
        document.getElementById("edituserreviews").value = review_array[item].Description;
        displayColorPopcorn('editpop', review_array[item].Rating);

    } else {
        window.alert("Please Log in to Edit Review");
    }
    
}

//This function sends the review data to the server for updating
function updateReview() {
    var response = confirm("Are you sure you want to update this review ?");

    if (response == true) {
        var edit_review_url = review_url + "/" + review_array[currentIndex].ReviewId;
        var updateReview = new XMLHttpRequest(); // new HttpRequest instance to send request to server
        updateReview.open("PUT", edit_review_url, true); //The HTTP method called 'PUT' is used here as we are updating data
        updateReview.setRequestHeader("Content-Type", "application/json");
        review_array[currentIndex].MemberName = document.getElementById("editMemberName").value;
        review_array[currentIndex].Description = document.getElementById("edituserreviews").value;
        review_array[currentIndex].Rating = Rating;
        updateReview.onload = function() {
            fetchReview();
        };
        updateReview.send(JSON.stringify(review_array[currentIndex]));
    }
}

//This function displayS the correct number of colored popcorn
//based on the Restaurant rating that is given in the user review
function displayColorPopcorn(classname, num) {
    var pop = document.getElementsByClassName(classname);
    var classTarget = "." + classname;

    for (let p of pop) {
        p.setAttribute("src", popcornBWImage);
    }
    changePopcornImage(num, classTarget);
}

//This function deletes the selected review in a specific Restaurant
function deleteReview(element) {
    var response = confirm("Are you sure you want to delete this review?");

    if (response == true) {
        var item = element.getAttribute("item"); //get the current item
        var delete_review_url = review_url + "/" + review_array[item].ReviewId;
        var erasereview = new XMLHttpRequest();
        erasereview.open("DELETE", delete_review_url, true);
        erasereview.onload = function() {
            fetchReview();
        };
        erasereview.send();
    }
}
