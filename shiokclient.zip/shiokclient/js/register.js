function registerMe(){

    var registerUser = new XMLHttpRequest();

    var confirmPassword = document.getElementById("confirmPassword").value

    registerUser.open("POST","http://127.0.0.2:8080/membersinfo",true);
    registerUser.setRequestHeader("Content-Type", "application/json");
    registerUser.onload = function(){
        
    }
    var Username = document.getElementById("Username").value;
    var Password = document.getElementById("Password").value;
    var Email = document.getElementById("Email").value;
    var payload = {Username:Username, Email:Email, Password:Password}
    if (Password == confirmPassword){
        $('#registerModal').modal('hide');
        $('#successModal').modal('show');
        registerUser.send(JSON.stringify(payload));
        
    } else{
        window.alert("Passswords do not match!")
    }
    
    
}