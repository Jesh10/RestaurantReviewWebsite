function logoutMe(){

    var response = confirm("Are you sure you want to Log Out?");

    if (response == true) {
        $('#registerMenu').show();
        $('#loginMenu').show();
        $('#logoutMenu').hide();
        $('#editMenu').hide();
        $('#profileImage').hide();
        
        sessionStorage.removeItem("token");
    }

    

}